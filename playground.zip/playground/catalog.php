<?php
require_once __DIR__ . '/includes/config.php';
$pageTitle = 'Catalog';

$db         = getDB();
$categories = $db->query("SELECT DISTINCT category FROM products WHERE is_active=1 ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
$products   = $db->query("SELECT * FROM products WHERE is_active=1 ORDER BY created_at DESC")->fetchAll();
$selectedCat = $_GET['category'] ?? '';
?>
<?php include 'includes/header.php'; ?>

<div class="page-content">

    <!-- Hero -->
    <div class="catalog-hero">
        <div class="container">
            <div class="section-eyebrow">Playground Collection</div>
            <h1>All Products</h1>
            <p>Every drop, every style — browse the full collection.</p>
        </div>
    </div>

    <div class="container">
        <div class="catalog-layout">

            <!-- ── Sidebar ── -->
            <aside class="catalog-sidebar">
                <div class="filter-card">
                    <h4>Filters</h4>

                    <!-- Category -->
                    <div class="filter-group">
                        <h5>Category</h5>
                        <?php foreach ($categories as $cat): ?>
                        <label class="filter-option">
                            <input type="checkbox" class="cat-filter" value="<?= htmlspecialchars($cat) ?>"
                                   <?= $selectedCat === $cat ? 'checked' : '' ?>>
                            <?= htmlspecialchars($cat) ?>
                        </label>
                        <?php endforeach; ?>
                    </div>

                    <!-- Price Range -->
                    <div class="filter-group">
                        <h5>Price Range</h5>
                        <label class="filter-option">
                            <input type="checkbox" class="price-filter" value="0-99.99"> Under RM100
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" class="price-filter" value="100-299.99"> RM100 – RM300
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" class="price-filter" value="300-499.99"> RM300 – RM500
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" class="price-filter" value="500-999999"> Over RM500
                        </label>
                    </div>

                    <button class="btn btn-outline btn-full btn-sm" id="clearBtn">Clear Filters</button>
                </div>
            </aside>

            <!-- ── Products ── -->
            <div class="catalog-main">

                <!-- Top bar -->
                <div class="catalog-top">
                    <div class="catalog-search">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                        <input type="text" id="catalogSearch" placeholder="Search products...">
                    </div>
                    <span class="catalog-count" id="catalogCount"><?= count($products) ?> products</span>
                    <div class="catalog-sort">
                        <select id="catalogSort">
                            <option value="default">Sort: Featured</option>
                            <option value="price-asc">Price: Low to High</option>
                            <option value="price-desc">Price: High to Low</option>
                            <option value="name-asc">Name: A – Z</option>
                            <option value="name-desc">Name: Z – A</option>
                        </select>
                    </div>
                </div>

                <!-- Product grid -->
                <div class="products-grid" id="productsGrid">
                    <?php foreach ($products as $p): ?>
                    <div class="product-col"
                         data-name="<?= strtolower(htmlspecialchars($p['name'])) ?>"
                         data-category="<?= strtolower(htmlspecialchars($p['category'])) ?>"
                         data-price="<?= floatval($p['price']) ?>">
                        <div class="product-card">
                            <div class="product-card-img">
                                <img src="<?= htmlspecialchars($p['image_url']) ?>"
                                     alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy">
                                <?php if ($p['stock'] <= 5 && $p['stock'] > 0): ?>
                                    <span class="product-badge" style="background:var(--danger)">Low Stock</span>
                                <?php elseif ($p['stock'] == 0): ?>
                                    <span class="product-badge" style="background:var(--muted)">Sold Out</span>
                                <?php endif; ?>
                            </div>
                            <div class="product-card-body">
                                <div class="product-category"><?= htmlspecialchars($p['category']) ?></div>
                                <div class="product-name"><?= htmlspecialchars($p['name']) ?></div>
                                <div class="product-price">RM<?= number_format($p['price'], 2) ?></div>
                                <div class="product-actions">
                                    <button class="btn btn-outline"
                                            onclick='openModal(<?= json_encode($p) ?>)'>View</button>
                                    <?php if ($p['stock'] > 0): ?>
                                    <button class="btn btn-primary"
                                            onclick='addToCart({
                                                id:        <?= (int)$p["id"] ?>,
                                                name:      <?= json_encode($p["name"]) ?>,
                                                price:     <?= floatval($p["price"]) ?>,
                                                image_url: <?= json_encode($p["image_url"]) ?>,
                                                category:  <?= json_encode($p["category"]) ?>,
                                                stock:     <?= (int)$p["stock"] ?>,
                                                qty:       1
                                            })'>Add</button>
                                    <?php else: ?>
                                    <button class="btn btn-dark" disabled>Sold Out</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- No results -->
                <div id="noResults" style="display:none;text-align:center;padding:4rem 2rem;">
                    <p style="color:var(--muted);font-size:1rem;margin-bottom:1rem;">No products match your filters.</p>
                    <button class="btn btn-outline" id="clearBtn2">Clear Filters</button>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Product Modal -->
<div class="modal-overlay" id="productModal">
    <div class="modal">
        <button class="modal-close" aria-label="Close">✕</button>
        <div class="modal-inner">
            <div class="modal-img">
                <img id="modal-img" src="" alt="">
            </div>
            <div class="modal-details">
                <div class="modal-category" id="modal-category"></div>
                <h2 class="modal-name"       id="modal-name"></h2>
                <div class="modal-price"     id="modal-price"></div>
                <p class="modal-desc"        id="modal-desc"></p>
                <div class="modal-stock"     id="modal-stock"></div>
                <div class="qty-control">
                    <button class="qty-btn" id="qty-minus">−</button>
                    <input  class="qty-val" id="modal-qty" type="number" value="1" min="1">
                    <button class="qty-btn" id="qty-plus">+</button>
                </div>
                <div class="modal-actions">
                    <button class="btn btn-primary btn-full" id="modal-add-btn">Add to Cart</button>
                    <button class="btn btn-outline btn-full" id="modal-buy-btn">Buy Now</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    // ─────────────────────────────────────────────
    // All filter + sort logic in ONE self-contained
    // function. No globals, no conflicts.
    // ─────────────────────────────────────────────

    const grid        = document.getElementById('productsGrid');
    const searchInput = document.getElementById('catalogSearch');
    const sortSelect  = document.getElementById('catalogSort');
    const countEl     = document.getElementById('catalogCount');
    const noResults   = document.getElementById('noResults');
    const totalCount  = <?= count($products) ?>;

    // Grab all product columns once
    function getCols() {
        return Array.from(grid.querySelectorAll('.product-col'));
    }

    function applyAll() {
        const query      = searchInput.value.trim().toLowerCase();
        const sortVal    = sortSelect.value;

        // Active category checkboxes
        const activeCats = Array.from(
            document.querySelectorAll('.cat-filter:checked')
        ).map(c => c.value.toLowerCase());

        // Active price range checkboxes
        const activePrices = Array.from(
            document.querySelectorAll('.price-filter:checked')
        ).map(c => c.value);

        const cols = getCols();

        // ── Step 1: Show / hide ──
        cols.forEach(col => {
            const name     = col.dataset.name     || '';
            const category = col.dataset.category || '';
            const price    = parseFloat(col.dataset.price) || 0;

            // Search
            const matchSearch = !query ||
                name.includes(query) ||
                category.includes(query);

            // Category
            const matchCat = activeCats.length === 0 ||
                activeCats.includes(category);

            // Price — must satisfy AT LEAST ONE checked range
            let matchPrice = activePrices.length === 0; // none checked = show all
            if (!matchPrice) {
                matchPrice = activePrices.some(range => {
                    const [min, max] = range.split('-').map(Number);
                    return price >= min && price <= max;
                });
            }

            col.style.display = (matchSearch && matchCat && matchPrice)
                ? '' : 'none';
        });

        // ── Step 2: Sort only visible cols ──
        const visible = cols.filter(c => c.style.display !== 'none');

        if (sortVal !== 'default') {
            visible.sort((a, b) => {
                const pa = parseFloat(a.dataset.price) || 0;
                const pb = parseFloat(b.dataset.price) || 0;
                const na = a.dataset.name || '';
                const nb = b.dataset.name || '';

                switch (sortVal) {
                    case 'price-asc':  return pa - pb;
                    case 'price-desc': return pb - pa;
                    case 'name-asc':   return na.localeCompare(nb);
                    case 'name-desc':  return nb.localeCompare(na);
                    default:           return 0;
                }
            });

            // Re-append in sorted order
            visible.forEach(col => grid.appendChild(col));
        }

        // ── Step 3: Update count + no-results ──
        const visCount = visible.length;
        if (countEl)   countEl.textContent     = `${visCount} product${visCount !== 1 ? 's' : ''}`;
        if (noResults) noResults.style.display = visCount === 0 ? 'block' : 'none';
    }

    function clearAll() {
        document.querySelectorAll('.cat-filter, .price-filter')
            .forEach(c => c.checked = false);
        searchInput.value = 'default';
        sortSelect.value  = 'default';
        searchInput.value = '';
        getCols().forEach(c => c.style.display = '');
        if (countEl)   countEl.textContent     = `${totalCount} products`;
        if (noResults) noResults.style.display = 'none';
    }

    // ── Event listeners ──
    searchInput.addEventListener('input',  applyAll);
    sortSelect.addEventListener('change',  applyAll);

    document.querySelectorAll('.cat-filter, .price-filter')
        .forEach(cb => cb.addEventListener('change', applyAll));

    document.getElementById('clearBtn')
        ?.addEventListener('click', clearAll);
    document.getElementById('clearBtn2')
        ?.addEventListener('click', clearAll);

    // ── Pre-select category from URL ?category=X ──
    const urlCat = new URLSearchParams(window.location.search).get('category');
    if (urlCat) {
        const cb = document.querySelector(`.cat-filter[value="${urlCat}"]`);
        if (cb) { cb.checked = true; applyAll(); }
    }

})(); // end IIFE — nothing leaks to global scope
</script>

<?php include 'includes/footer.php'; ?>
