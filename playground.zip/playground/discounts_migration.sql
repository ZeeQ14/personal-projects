-- ============================================================
-- Playground — Discounts Migration
-- Run this in phpMyAdmin SQL tab on your playground_db
-- ============================================================

CREATE TABLE IF NOT EXISTS discounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    type ENUM('special_day', 'minimum_spend') NOT NULL,
    discount_percent DECIMAL(5,2) NOT NULL DEFAULT 10.00,
    minimum_spend DECIMAL(10,2) DEFAULT NULL,
    start_date DATE DEFAULT NULL,
    end_date DATE DEFAULT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default: RM500 minimum spend discount
INSERT INTO discounts (name, type, discount_percent, minimum_spend, is_active)
VALUES ('Spend RM500 & Save', 'minimum_spend', 10.00, 500.00, 1);

-- Example: Hari Merdeka Sale (Aug 31)
INSERT INTO discounts (name, type, discount_percent, start_date, end_date, is_active)
VALUES ('Hari Merdeka Sale 🇲🇾', 'special_day', 10.00, '2025-08-31', '2025-08-31', 1);

-- Add discount columns to orders table
ALTER TABLE orders
    ADD COLUMN discount_id INT DEFAULT NULL AFTER total_amount,
    ADD COLUMN discount_amount DECIMAL(10,2) DEFAULT 0.00 AFTER discount_id,
    ADD COLUMN subtotal_amount DECIMAL(10,2) DEFAULT NULL AFTER discount_amount,
    ADD FOREIGN KEY (discount_id) REFERENCES discounts(id) ON DELETE SET NULL;
