<?php
require_once __DIR__ . '/includes/config.php';
$pageTitle = 'Cart';

// Get active sale events for banner
$saleEvents = getActiveSaleEvents();
?>
<?php include 'includes/header.php'; ?>

<style>
/* Discount badge */
.discount-banner {
    background: linear-gradient(135deg, rgba(200,169,110,0.15), rgba(200,169,110,0.05));
    border: 1px solid rgba(200,169,110,0.35);
    border-radius: var(--radius);
    padding: 0.85rem 1.25rem;
    display: flex; align-items: center; gap: 0.75rem;
    font-size: 0.88rem; color: var(--accent);
    margin-bottom: 1.25rem;
    animation: pulse-border 2s infinite;
}
@keyframes pulse-border {
    0%, 100% { border-color: rgba(200,169,110,0.35); }
    50%       { border-color: rgba(200,169,110,0.65); }
}
.discount-banner strong { color: var(--white); }
.discount-banner .badge {
    background: var(--accent); color: var(--black);
    font-size: 0.7rem; font-weight: 700;
    padding: 0.2rem 0.55rem; border-radius: 20px;
    letter-spacing: 0.05em; flex-shrink: 0;
}

/* Progress bar toward discount */
.spend-progress-wrap {
    background: var(--off-black);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 1rem 1.25rem;
    margin-bottom: 1rem;
}
.spend-progress-label {
    display: flex; justify-content: space-between;
    font-size: 0.78rem; color: var(--muted);
    margin-bottom: 0.6rem;
}
.spend-progress-label span { color: var(--accent); font-weight: 500; }
.spend-bar {
    height: 5px; background: var(--border);
    border-radius: 3px; overflow: hidden;
}
.spend-fill {
    height: 100%; background: var(--accent);
    border-radius: 3px;
    transition: width 0.5s ease;
}

/* Discount line in summary */
.summary-discount {
    color: var(--success) !important;
    font-weight: 500;
}
.summary-discount-label { color: var(--success) !important; }
</style>

<div class="page-content cart-page">
    <div class="container">
        <h1 style="margin-bottom:0.5rem;">Your Cart</h1>
        <p style="color:var(--muted);font-size:0.88rem;margin-bottom:1.5rem;">Review your items before checkout.</p>

        <!-- Active sale event banners -->
        <?php foreach ($saleEvents as $sale): ?>
        <div class="discount-banner">
            <span class="badge"><?= $sale['discount_percent'] ?>% OFF</span>
            <div>
                <strong><?= htmlspecialchars($sale['name']) ?></strong> is live!
                Discount applied automatically at checkout.
                <?php if ($sale['end_date']): ?>
                    Ends <?= date('M j', strtotime($sale['end_date'])) ?>.
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>

        <div class="cart-layout">
            <!-- Cart items rendered by JS -->
            <div id="cartContainer">
                <div style="text-align:center;padding:3rem;color:var(--muted);">Loading cart...</div>
            </div>

            <!-- Order Summary -->
            <div id="orderSummarySection">
                <div class="order-summary">
                    <h3>Order Summary</h3>

                    <!-- Spend progress toward RM500 discount -->
                    <div class="spend-progress-wrap" id="spendProgressWrap">
                        <div class="spend-progress-label">
                            <div id="spendProgressText">Spend RM<?= number_format(MIN_SPEND_DISCOUNT, 0) ?> to get 10% off</div>
                            <span id="spendProgressAmt"></span>
                        </div>
                        <div class="spend-bar">
                            <div class="spend-fill" id="spendFill" style="width:0%"></div>
                        </div>
                    </div>

                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span id="summarySubtotal">RM0.00</span>
                    </div>
                    <div class="summary-row summary-discount-label" id="discountRow" style="display:none;">
                        <span id="discountLabel">Discount</span>
                        <span class="summary-discount" id="summaryDiscount"></span>
                    </div>
                    <div class="summary-row">
                        <span>Shipping</span>
                        <span id="summaryShipping">RM<?= number_format(SHIPPING_FEE, 2) ?></span>
                    </div>
                    <div class="summary-row" style="font-size:0.76rem;color:var(--muted);">
                        <span>Free shipping over RM<?= number_format(FREE_SHIPPING_THRESHOLD, 0) ?></span>
                    </div>
                    <div class="summary-row total">
                        <span>Total</span>
                        <span id="summaryTotal">RM0.00</span>
                    </div>

                    <?php if (isLoggedIn()): ?>
                        <a href="<?= SITE_URL ?>/checkout.php" class="btn btn-primary btn-full" style="margin-top:1.25rem;">
                            Proceed to Checkout
                        </a>
                    <?php else: ?>
                        <a href="<?= SITE_URL ?>/login.php?redirect=<?= urlencode(SITE_URL . '/checkout.php') ?>"
                           class="btn btn-primary btn-full" style="margin-top:1.25rem;">
                            Login to Checkout
                        </a>
                        <p style="font-size:0.78rem;color:var(--muted);text-align:center;margin-top:0.75rem;">
                            You need an account to place an order.
                        </p>
                    <?php endif; ?>

                    <a href="<?= SITE_URL ?>/catalog.php" class="btn btn-outline btn-full" style="margin-top:0.75rem;">
                        Continue Shopping
                    </a>

                    <div style="margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--border);text-align:center;">
                        <p style="font-size:0.75rem;color:var(--muted);">Secured by PayPal</p>
                        <div style="display:flex;justify-content:center;gap:0.5rem;margin-top:0.5rem;font-size:0.7rem;color:var(--muted);">
                            <span>🔒 SSL Encrypted</span>
                            <span>•</span>
                            <span>PayPal Buyer Protection</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Pass PHP constants to JS
const FREE_SHIPPING_THRESHOLD = <?= FREE_SHIPPING_THRESHOLD ?>;
const SHIPPING_FEE            = <?= SHIPPING_FEE ?>;
const MIN_SPEND_DISCOUNT      = <?= MIN_SPEND_DISCOUNT ?>;
const MIN_SPEND_DISCOUNT_PCT  = <?= MIN_SPEND_DISCOUNT_PCT ?>;

// Active sale events from server
const saleEvents = <?= json_encode($saleEvents) ?>;

// ── Discount engine (mirrors PHP calculateOrder logic) ──
function getDiscount(subtotal) {
    // Check special day discounts from server data
    let bestDiscount = null;

    saleEvents.forEach(ev => {
        if (!bestDiscount || ev.discount_percent > bestDiscount.pct) {
            bestDiscount = { name: ev.name, pct: parseFloat(ev.discount_percent), type: 'special_day' };
        }
    });

    // Check minimum spend discount
    if (subtotal >= MIN_SPEND_DISCOUNT) {
        if (!bestDiscount || MIN_SPEND_DISCOUNT_PCT > bestDiscount.pct) {
            bestDiscount = { name: `${MIN_SPEND_DISCOUNT_PCT}% off — Spend RM${MIN_SPEND_DISCOUNT.toLocaleString()}`, pct: MIN_SPEND_DISCOUNT_PCT, type: 'minimum_spend' };
        }
    }

    return bestDiscount;
}

function calculateOrder(subtotal) {
    const discount       = getDiscount(subtotal);
    const discountAmount = discount ? Math.round(subtotal * (discount.pct / 100) * 100) / 100 : 0;
    const afterDiscount  = subtotal - discountAmount;
    const shipping       = afterDiscount >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
    const grandTotal     = afterDiscount + shipping;

    return { subtotal, discount, discountAmount, afterDiscount, shipping, grandTotal };
}

// ── Override renderCartPage to update summary with discounts ──
const _origRender = window.renderCartPage;

function updateSummary() {
    const subtotal = getCartTotal();
    const order    = calculateOrder(subtotal);

    // Update subtotal
    document.getElementById('summarySubtotal').textContent = 'RM' + order.subtotal.toFixed(2);

    // Discount row
    const discountRow   = document.getElementById('discountRow');
    const discountLabel = document.getElementById('discountLabel');
    const discountAmt   = document.getElementById('summaryDiscount');

    if (order.discount && order.discountAmount > 0) {
        discountRow.style.display = '';
        discountLabel.textContent = `${order.discount.name} (${order.discount.pct}% off)`;
        discountAmt.textContent   = '− RM' + order.discountAmount.toFixed(2);
    } else {
        discountRow.style.display = 'none';
    }

    // Shipping
    document.getElementById('summaryShipping').textContent =
        order.shipping === 0 ? 'FREE' : 'RM' + order.shipping.toFixed(2);

    // Total
    document.getElementById('summaryTotal').textContent = 'RM' + order.grandTotal.toFixed(2);

    // Spend progress bar
    updateSpendProgress(subtotal);

    // Store for checkout
    window._checkoutTotal    = order.grandTotal.toFixed(2);
    window._checkoutDiscount = order;
}

function updateSpendProgress(subtotal) {
    const wrap  = document.getElementById('spendProgressWrap');
    const text  = document.getElementById('spendProgressText');
    const amt   = document.getElementById('spendProgressAmt');
    const fill  = document.getElementById('spendFill');

    if (!wrap) return;

    const threshold = MIN_SPEND_DISCOUNT;
    const pct       = Math.min((subtotal / threshold) * 100, 100);

    fill.style.width = pct + '%';

    if (subtotal >= threshold) {
        text.textContent = '🎉 10% discount applied!';
        amt.textContent  = '';
        fill.style.background = 'var(--success)';
    } else {
        const remaining = threshold - subtotal;
        text.textContent = `Spend RM${remaining.toFixed(2)} more for 10% off`;
        amt.textContent  = `RM${subtotal.toFixed(2)} / RM${threshold.toFixed(0)}`;
        fill.style.background = 'var(--accent)';
    }
}

// Hook into cart rendering
document.addEventListener('DOMContentLoaded', () => {
    // Patch renderCartPage to also update summary
    const origRender = window.renderCartPage;
    if (origRender) {
        window.renderCartPage = function() {
            origRender();
            updateSummary();
        };
    }
    updateSummary();
});

// Also update on cart changes
const origSave = window.saveCart;
if (typeof origSave === 'function') {
    window.saveCart = function(cart) {
        origSave(cart);
        setTimeout(updateSummary, 50);
    };
}
</script>

<?php include 'includes/footer.php'; ?>
