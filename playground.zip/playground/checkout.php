<?php
require_once __DIR__ . '/includes/config.php';
requireLogin();
$pageTitle = 'Checkout';
$user = getCurrentUser();

// Get active sale events for display
$saleEvents = getActiveSaleEvents();

$extraHead = '<script src="https://www.paypal.com/sdk/js?client-id=' . PAYPAL_CLIENT_ID . '&currency=MYR"></script>';
?>
<?php include 'includes/header.php'; ?>

<style>
.discount-applied {
    display: flex; align-items: center; gap: 0.6rem;
    background: rgba(82,201,122,0.08);
    border: 1px solid rgba(82,201,122,0.25);
    border-radius: var(--radius);
    padding: 0.7rem 1rem;
    font-size: 0.82rem; color: var(--success);
    margin-bottom: 1rem;
}
.discount-applied strong { color: var(--white); }
</style>

<div class="page-content checkout-page">
    <div class="container">
        <h1 style="margin-bottom:0.5rem;">Checkout</h1>
        <p style="color:var(--muted);font-size:0.88rem;margin-bottom:2.5rem;">Complete your order securely with PayPal.</p>

        <div class="checkout-layout">
            <!-- Left: Shipping + Payment -->
            <div>
                <!-- Shipping Info -->
                <div class="checkout-section">
                    <h3>Shipping Information</h3>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" id="ship-name" value="<?= htmlspecialchars($user['name']) ?>">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" id="ship-email" value="<?= htmlspecialchars($user['email']) ?>">
                        </div>
                        <div class="form-group" style="grid-column:1/-1;">
                            <label>Street Address</label>
                            <input type="text" id="ship-address" placeholder="No. 12, Jalan ...">
                        </div>
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" id="ship-city" placeholder="Kuala Lumpur">
                        </div>
                        <div class="form-group">
                            <label>Postcode</label>
                            <input type="text" id="ship-zip" placeholder="50000">
                        </div>
                        <div class="form-group">
                            <label>State</label>
                            <select id="ship-state">
                                <option value="">— Select State —</option>
                                <?php foreach (['Johor','Kedah','Kelantan','Melaka','Negeri Sembilan','Pahang','Perak','Perlis','Pulau Pinang','Sabah','Sarawak','Selangor','Terengganu','Kuala Lumpur','Labuan','Putrajaya'] as $s): ?>
                                <option><?= $s ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Country</label>
                            <input type="text" id="ship-country" value="Malaysia" readonly style="opacity:0.6;">
                        </div>
                    </div>
                </div>

                <!-- Payment -->
                <div class="checkout-section">
                    <h3>Payment</h3>
                    <p style="font-size:0.85rem;color:var(--silver);margin-bottom:1.25rem;">
                        Your order will be processed securely through PayPal. Pay with your PayPal account or any major credit/debit card.
                    </p>
                    <div id="discount-notice"></div>
                    <div id="paypal-button-container"></div>
                    <div id="payment-message" style="display:none;" class="alert alert-error"></div>
                </div>
            </div>

            <!-- Right: Order Summary -->
            <div>
                <div class="checkout-order-summary">
                    <h3 style="font-size:0.88rem;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;color:var(--silver);margin-bottom:1.25rem;padding-bottom:0.75rem;border-bottom:1px solid var(--border);">
                        Order Summary
                    </h3>
                    <div id="checkoutItems"></div>

                    <div style="border-top:1px solid var(--border);margin-top:1rem;padding-top:1rem;">
                        <div class="summary-row"><span>Subtotal</span><span id="coSubtotal">RM0.00</span></div>
                        <div class="summary-row" id="coDiscountRow" style="display:none;">
                            <span id="coDiscountLabel" style="color:var(--success);font-size:0.82rem;"></span>
                            <span id="coDiscountAmt" style="color:var(--success);font-weight:500;"></span>
                        </div>
                        <div class="summary-row"><span>Shipping</span><span id="coShipping">RM0.00</span></div>
                        <div class="summary-row total"><span>Total</span><span id="coTotal">RM0.00</span></div>
                    </div>

                    <div style="margin-top:1.25rem;padding:0.85rem;background:rgba(82,201,122,0.06);border:1px solid rgba(82,201,122,0.2);border-radius:4px;">
                        <p style="font-size:0.76rem;color:var(--success);text-align:center;">
                            🔒 Secured by PayPal Buyer Protection
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const FREE_SHIPPING_THRESHOLD = <?= FREE_SHIPPING_THRESHOLD ?>;
const SHIPPING_FEE            = <?= SHIPPING_FEE ?>;
const MIN_SPEND_DISCOUNT      = <?= MIN_SPEND_DISCOUNT ?>;
const MIN_SPEND_DISCOUNT_PCT  = <?= MIN_SPEND_DISCOUNT_PCT ?>;
const saleEvents              = <?= json_encode($saleEvents) ?>;

function getDiscount(subtotal) {
    let best = null;
    saleEvents.forEach(ev => {
        if (!best || parseFloat(ev.discount_percent) > best.pct) {
            best = { id: ev.id, name: ev.name, pct: parseFloat(ev.discount_percent), type: 'special_day' };
        }
    });
    if (subtotal >= MIN_SPEND_DISCOUNT) {
        if (!best || MIN_SPEND_DISCOUNT_PCT > best.pct) {
            best = { id: null, name: `${MIN_SPEND_DISCOUNT_PCT}% off — Spend RM${MIN_SPEND_DISCOUNT.toLocaleString()}`, pct: MIN_SPEND_DISCOUNT_PCT, type: 'minimum_spend' };
        }
    }
    return best;
}

function calculateOrder(subtotal) {
    const discount       = getDiscount(subtotal);
    const discountAmount = discount ? Math.round(subtotal * (discount.pct / 100) * 100) / 100 : 0;
    const afterDiscount  = subtotal - discountAmount;
    const shipping       = afterDiscount >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
    const grandTotal     = afterDiscount + shipping;
    return { subtotal, discount, discountAmount, afterDiscount, shipping, grandTotal };
}

document.addEventListener('DOMContentLoaded', () => {
    const cart = JSON.parse(localStorage.getItem('playground_cart') || '[]');

    if (!cart.length) {
        window.location.href = '/playground/cart.php';
        return;
    }

    // Render items
    const itemsEl = document.getElementById('checkoutItems');
    itemsEl.innerHTML = cart.map(item => `
        <div class="checkout-item">
            <div class="checkout-item-img"><img src="${item.image_url}" alt="${item.name}"></div>
            <div class="checkout-item-info">
                <div class="checkout-item-name">${item.name}</div>
                <div class="checkout-item-qty">Qty: ${item.qty}</div>
            </div>
            <div class="checkout-item-price">RM${(item.price * item.qty).toFixed(2)}</div>
        </div>`).join('');

    // Calculate
    const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
    const order    = calculateOrder(subtotal);

    // Update summary
    document.getElementById('coSubtotal').textContent = 'RM' + order.subtotal.toFixed(2);
    document.getElementById('coShipping').textContent = order.shipping === 0 ? 'FREE' : 'RM' + order.shipping.toFixed(2);
    document.getElementById('coTotal').textContent    = 'RM' + order.grandTotal.toFixed(2);

    // Discount row
    if (order.discount && order.discountAmount > 0) {
        document.getElementById('coDiscountRow').style.display  = '';
        document.getElementById('coDiscountLabel').textContent  = order.discount.name;
        document.getElementById('coDiscountAmt').textContent    = '− RM' + order.discountAmount.toFixed(2);

        // Show notice near PayPal button
        document.getElementById('discount-notice').innerHTML = `
            <div class="discount-applied">
                🎉 <strong>${order.discount.pct}% discount</strong> applied — saving RM${order.discountAmount.toFixed(2)}!
            </div>`;
    }

    window._checkoutTotal    = order.grandTotal.toFixed(2);
    window._checkoutCart     = cart;
    window._checkoutDiscount = order;

    // ── PayPal ──
    if (typeof paypal === 'undefined') {
        document.getElementById('paypal-button-container').innerHTML =
            '<div class="alert alert-info">PayPal is not configured yet. Add your Client ID in includes/config.php</div>';
        return;
    }

    paypal.Buttons({
        style: { layout: 'vertical', color: 'gold', shape: 'rect', label: 'paypal' },

        createOrder(data, actions) {
            return actions.order.create({
                purchase_units: [{
                    description: 'Playground Clothing Order',
                    amount: {
                        currency_code: 'MYR',
                        value: window._checkoutTotal,
                        breakdown: {
                            item_total: { currency_code: 'MYR', value: window._checkoutTotal }
                        }
                    }
                }]
            });
        },

        onApprove(data, actions) {
            return actions.order.capture().then(details => {
                const disc = window._checkoutDiscount;
                fetch('/playground/api/create_order.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        paypal_order_id:  data.orderID,
                        paypal_payer_id:  details.payer.payer_id,
                        total:            window._checkoutTotal,
                        subtotal:         disc.subtotal,
                        discount_id:      disc.discount ? disc.discount.id : null,
                        discount_amount:  disc.discountAmount,
                        shipping:         disc.shipping,
                        cart: cart,
                        shipping_info: {
                            name:    document.getElementById('ship-name').value,
                            email:   document.getElementById('ship-email').value,
                            address: document.getElementById('ship-address').value,
                            city:    document.getElementById('ship-city').value,
                            zip:     document.getElementById('ship-zip').value,
                            state:   document.getElementById('ship-state').value,
                            country: 'Malaysia',
                        }
                    })
                })
                .then(r => r.json())
                .then(res => {
                    if (res.success) {
                        localStorage.removeItem('playground_cart');
                        window.location.href = '/playground/orders.php?success=1&order=' + res.order_id;
                    } else {
                        showPaymentError(res.error || 'Order processing failed.');
                    }
                })
                .catch(() => showPaymentError('Network error. Please contact support.'));
            });
        },

        onError(err) {
            showPaymentError('Payment failed. Please try again.');
            console.error('PayPal error:', err);
        },

        onCancel() { showToast('Payment cancelled.', 'info'); }

    }).render('#paypal-button-container');

    function showPaymentError(msg) {
        const el = document.getElementById('payment-message');
        el.textContent   = msg;
        el.style.display = 'block';
    }
});
</script>

<?php include 'includes/footer.php'; ?>
