<?php
// =============================================================
// PLAYGROUND — Configuration File
// =============================================================

// --- Database Configuration ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'playground_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// --- PayPal Configuration ---
define('PAYPAL_MODE', 'sandbox');
define('PAYPAL_CLIENT_ID', 'AUY0MWhXmLMHH40oI3nLL7FuFq0hOqymPbvNJ6ELMiFjypawa74XNN4cxNSV7-Gvl5SlQUbQFHLMphYq');
define('PAYPAL_CLIENT_SECRET', 'ECdKdcPmE4BvP34a8D4H49mZjRfsmpVPNoJ3_Qvyg2smWuwFC3_ZiLXLzb4oQRppejiBsJ_dkrjeM3fu');

if (PAYPAL_MODE === 'live') {
    define('PAYPAL_API_URL', 'https://api-m.paypal.com');
} else {
    define('PAYPAL_API_URL', 'https://api-m.sandbox.paypal.com');
}

// --- Site Configuration ---
define('SITE_NAME', 'Playground');
define('SITE_URL', 'http://localhost/playground');
define('CURRENCY', 'MYR');
define('CURRENCY_SYMBOL', 'RM');

// --- Shipping ---
define('FREE_SHIPPING_THRESHOLD', 500.00);  // Free shipping over RM500
define('SHIPPING_FEE', 15.00);              // Flat shipping fee RM15

// --- Discounts ---
define('MIN_SPEND_DISCOUNT', 500.00);       // 10% off when cart >= RM500
define('MIN_SPEND_DISCOUNT_PCT', 10);

// --- Session ---
define('SESSION_LIFETIME', 3600);

// =============================================================
// Database Connection
// =============================================================
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// =============================================================
// Session & Auth Helpers
// =============================================================
function startSession() {
    if (session_status() === PHP_SESSION_NONE) session_start();
}
function isLoggedIn() {
    startSession();
    return isset($_SESSION['user_id']);
}
function isAdmin() {
    startSession();
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . SITE_URL . '/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}
function requireAdmin() {
    if (!isAdmin()) {
        header('Location: ' . SITE_URL . '/index.php');
        exit;
    }
}
function getCurrentUser() {
    startSession();
    if (!isLoggedIn()) return null;
    return [
        'id'    => $_SESSION['user_id'],
        'name'  => $_SESSION['user_name'],
        'email' => $_SESSION['user_email'],
        'role'  => $_SESSION['role'],
    ];
}

// =============================================================
// Discount Helpers
// =============================================================

/**
 * Get the best applicable discount for a given cart subtotal.
 * Returns the discount row or null.
 * Priority: apply the bigger discount only.
 */
function getApplicableDiscount(float $subtotal): ?array {
    try {
        $db   = getDB();
        $today = date('Y-m-d');

        // Fetch all active discounts
        $stmt = $db->query("SELECT * FROM discounts WHERE is_active = 1");
        $all  = $stmt->fetchAll();

        $best = null;

        foreach ($all as $discount) {
            $applies = false;

            if ($discount['type'] === 'minimum_spend') {
                // Check if subtotal meets minimum spend
                if ($subtotal >= floatval($discount['minimum_spend'])) {
                    $applies = true;
                }
            } elseif ($discount['type'] === 'special_day') {
                // Check if today falls within the date range
                $start = $discount['start_date'];
                $end   = $discount['end_date'];
                if ($start && $end && $today >= $start && $today <= $end) {
                    $applies = true;
                } elseif ($start && !$end && $today === $start) {
                    $applies = true;
                }
            }

            if ($applies) {
                // Keep the discount with the highest percent
                if ($best === null || floatval($discount['discount_percent']) > floatval($best['discount_percent'])) {
                    $best = $discount;
                }
            }
        }

        return $best;

    } catch (Exception $e) {
        return null;
    }
}

/**
 * Calculate full order breakdown.
 * Returns array: subtotal, discount, discount_amount, total, shipping, grand_total
 */
function calculateOrder(float $subtotal): array {
    $discount        = getApplicableDiscount($subtotal);
    $discountAmount  = 0.00;
    $discountPct     = 0;

    if ($discount) {
        $discountPct    = floatval($discount['discount_percent']);
        $discountAmount = round($subtotal * ($discountPct / 100), 2);
    }

    $afterDiscount = $subtotal - $discountAmount;
    $shipping      = $afterDiscount >= FREE_SHIPPING_THRESHOLD ? 0.00 : SHIPPING_FEE;
    $grandTotal    = $afterDiscount + $shipping;

    return [
        'subtotal'        => $subtotal,
        'discount'        => $discount,
        'discount_pct'    => $discountPct,
        'discount_amount' => $discountAmount,
        'after_discount'  => $afterDiscount,
        'shipping'        => $shipping,
        'grand_total'     => $grandTotal,
    ];
}

/**
 * Get all currently active special day discounts for display (banners etc.)
 */
function getActiveSaleEvents(): array {
    try {
        $db    = getDB();
        $today = date('Y-m-d');
        $stmt  = $db->prepare("
            SELECT * FROM discounts
            WHERE is_active = 1
              AND type = 'special_day'
              AND start_date <= ?
              AND end_date >= ?
        ");
        $stmt->execute([$today, $today]);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}
