<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Manage Discounts';
$db = getDB();
$msg = ''; $error = '';

// Malaysian public holidays for quick-add
$myHolidays = [
    ['name' => 'Hari Merdeka Sale 🇲🇾',     'start' => date('Y') . '-08-31', 'end' => date('Y') . '-08-31'],
    ['name' => 'Malaysia Day Sale 🇲🇾',       'start' => date('Y') . '-09-16', 'end' => date('Y') . '-09-16'],
    ['name' => 'Hari Raya Aidilfitri Sale 🌙','start' => '', 'end' => ''],
    ['name' => 'Chinese New Year Sale 🧧',    'start' => '', 'end' => ''],
    ['name' => 'Deepavali Sale 🪔',           'start' => '', 'end' => ''],
    ['name' => 'Christmas Sale 🎄',           'start' => date('Y') . '-12-24', 'end' => date('Y') . '-12-26'],
    ['name' => 'New Year Sale 🎉',            'start' => date('Y') . '-12-31', 'end' => (date('Y')+1) . '-01-01'],
    ['name' => '11.11 Sale',                  'start' => date('Y') . '-11-11', 'end' => date('Y') . '-11-11'],
    ['name' => '12.12 Sale',                  'start' => date('Y') . '-12-12', 'end' => date('Y') . '-12-12'],
];

// Handle add
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_discount'])) {
    $name    = trim($_POST['name'] ?? '');
    $type    = $_POST['type'] ?? 'special_day';
    $pct     = floatval($_POST['discount_percent'] ?? 10);
    $minSpend= floatval($_POST['minimum_spend'] ?? 0);
    $start   = $_POST['start_date'] ?? null;
    $end     = $_POST['end_date'] ?? null;

    if (!$name || $pct <= 0 || $pct > 100) {
        $error = 'Please fill in all required fields with valid values.';
    } else {
        $db->prepare("INSERT INTO discounts (name, type, discount_percent, minimum_spend, start_date, end_date, is_active) VALUES (?,?,?,?,?,?,1)")
           ->execute([$name, $type, $pct, $type === 'minimum_spend' ? $minSpend : null, $start ?: null, $end ?: null]);
        $msg = 'Discount "' . htmlspecialchars($name) . '" added successfully.';
    }
}

// Handle quick-add holiday
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quick_add'])) {
    $idx = intval($_POST['holiday_index']);
    if (isset($myHolidays[$idx])) {
        $h   = $myHolidays[$idx];
        $pct = floatval($_POST['quick_pct'] ?? 10);
        $db->prepare("INSERT INTO discounts (name, type, discount_percent, start_date, end_date, is_active) VALUES (?,?,?,?,?,1)")
           ->execute([$h['name'], 'special_day', $pct, $h['start'] ?: null, $h['end'] ?: null]);
        $msg = '"' . $h['name'] . '" sale added!';
    }
}

// Handle toggle active
if (isset($_GET['toggle'])) {
    $id = intval($_GET['toggle']);
    $db->prepare("UPDATE discounts SET is_active = 1 - is_active WHERE id=?")->execute([$id]);
    header('Location: ' . SITE_URL . '/admin/discounts.php?msg=updated');
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $db->prepare("DELETE FROM discounts WHERE id=?")->execute([$id]);
    header('Location: ' . SITE_URL . '/admin/discounts.php?msg=deleted');
    exit;
}

if (isset($_GET['msg'])) $msg = 'Discount updated.';

$discounts = $db->query("SELECT * FROM discounts ORDER BY is_active DESC, created_at DESC")->fetchAll();
$today = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discounts — Admin — Playground</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
<style>
.holiday-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:0.75rem; margin-bottom:1.5rem; }
.holiday-card {
    background:var(--charcoal); border:1px solid var(--border);
    border-radius:var(--radius); padding:1rem;
    display:flex; flex-direction:column; gap:0.6rem;
}
.holiday-card h5 { font-size:0.88rem; color:var(--white); font-family:var(--font-body); }
.holiday-card .dates { font-size:0.72rem; color:var(--muted); }
.holiday-card form { display:flex; gap:0.4rem; align-items:center; }
.holiday-card input[type="number"] {
    width:58px; background:var(--mid); border:1px solid var(--border);
    border-radius:4px; padding:0.3rem 0.5rem;
    color:var(--off-white); font-size:0.78rem; outline:none;
}
.active-pill {
    font-size:0.68rem; font-weight:700; letter-spacing:0.1em; text-transform:uppercase;
    padding:0.2rem 0.55rem; border-radius:20px;
}
.pill-active   { background:rgba(82,201,122,0.15); color:var(--success); }
.pill-inactive { background:rgba(100,100,100,0.15); color:var(--muted); }
.pill-live     { background:rgba(200,169,110,0.2); color:var(--accent); }
.type-badge {
    font-size:0.68rem; padding:0.15rem 0.5rem; border-radius:3px;
    font-weight:600; text-transform:uppercase; letter-spacing:0.06em;
}
.type-spend { background:rgba(100,140,255,0.12); color:#7ba7ff; }
.type-day   { background:rgba(200,169,110,0.12); color:var(--accent); }
</style>
</head>
<body>
<?php include __DIR__ . '/../includes/header.php'; ?>
<div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <span>Admin Panel</span>
        </div>
        <nav class="admin-nav">
            <a href="<?= SITE_URL ?>/admin/dashboard.php" class="active">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Dashboard
            </a>
            <a href="<?= SITE_URL ?>/admin/orders.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>
                Orders
            </a>
            <a href="<?= SITE_URL ?>/admin/products.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                Products
            </a>
            <a href="<?= SITE_URL ?>/admin/discounts.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                Discounts
            </a>
            <a href="<?= SITE_URL ?>/admin/customers.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                Customers
            </a>
            <a href="<?= SITE_URL ?>/admin/reports.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                Reports
            </a>
            <a href="<?= SITE_URL ?>/index.php" style="margin-top:1rem;border-top:1px solid var(--border);padding-top:1rem;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                View Store
            </a>
        </nav>
    </aside>
    <main class="admin-main">
        <div class="admin-header">
            <h1>Discounts</h1>
        </div>

        <?php if ($msg): ?><div class="alert alert-success" style="margin-bottom:1.5rem;"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error" style="margin-bottom:1.5rem;"><?= htmlspecialchars($error) ?></div><?php endif; ?>

        <!-- ── Quick Add Malaysian Holidays ── -->
        <div class="admin-card" style="margin-bottom:1.5rem;">
            <div class="admin-card-header">
                <h3>Quick Add — Malaysian Sale Events</h3>
                <span style="font-size:0.75rem;color:var(--muted);">Click + to add with custom % discount</span>
            </div>
            <div style="padding:1.25rem 1.5rem;">
                <div class="holiday-grid">
                    <?php foreach ($myHolidays as $i => $h): ?>
                    <div class="holiday-card">
                        <h5><?= $h['name'] ?></h5>
                        <div class="dates">
                            <?php if ($h['start']): ?>
                                <?= date('M j', strtotime($h['start'])) ?>
                                <?= $h['start'] !== $h['end'] ? ' – ' . date('M j', strtotime($h['end'])) : '' ?>
                            <?php else: ?>
                                <em>Set date manually</em>
                            <?php endif; ?>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="holiday_index" value="<?= $i ?>">
                            <input type="number" name="quick_pct" value="10" min="1" max="99" step="1"> %
                            <button type="submit" name="quick_add" class="btn btn-primary btn-sm">+ Add</button>
                        </form>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- ── Add Custom Discount ── -->
        <div class="admin-card" style="margin-bottom:1.5rem;">
            <div class="admin-card-header"><h3>Add Custom Discount</h3></div>
            <div style="padding:1.5rem;">
                <form method="POST" id="addForm">
                    <div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:1rem;margin-bottom:1rem;">
                        <div class="form-group" style="margin-bottom:0;">
                            <label>Discount Name *</label>
                            <input type="text" name="name" placeholder="e.g. Hari Raya Sale 🌙" required>
                        </div>
                        <div class="form-group" style="margin-bottom:0;">
                            <label>Type *</label>
                            <select name="type" id="typeSelect" onchange="toggleTypeFields()">
                                <option value="special_day">Special Day</option>
                                <option value="minimum_spend">Minimum Spend</option>
                            </select>
                        </div>
                        <div class="form-group" style="margin-bottom:0;">
                            <label>Discount % *</label>
                            <input type="number" name="discount_percent" value="10" min="1" max="99" step="0.5" required>
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;">
                        <div class="form-group" id="minSpendField" style="display:none;margin-bottom:0;">
                            <label>Minimum Spend (RM)</label>
                            <input type="number" name="minimum_spend" value="500" min="0" step="10">
                        </div>
                        <div class="form-group" id="startDateField" style="margin-bottom:0;">
                            <label>Start Date</label>
                            <input type="date" name="start_date">
                        </div>
                        <div class="form-group" id="endDateField" style="margin-bottom:0;">
                            <label>End Date</label>
                            <input type="date" name="end_date">
                        </div>
                    </div>
                    <button type="submit" name="add_discount" class="btn btn-primary" style="margin-top:1.25rem;">Add Discount</button>
                </form>
            </div>
        </div>

        <!-- ── All Discounts Table ── -->
        <div class="admin-card">
            <div class="admin-card-header">
                <h3>All Discounts</h3>
                <span style="font-size:0.75rem;color:var(--muted);"><?= count($discounts) ?> total</span>
            </div>
            <table class="admin-table">
                <thead>
                    <tr><th>Name</th><th>Type</th><th>Discount</th><th>Condition</th><th>Date Range</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($discounts)): ?>
                    <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:2rem;">No discounts yet.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($discounts as $d):
                        $isLive = $d['is_active'] && $d['type'] === 'special_day'
                                  && $d['start_date'] && $d['end_date']
                                  && $today >= $d['start_date'] && $today <= $d['end_date'];
                        $isLive = $isLive || ($d['is_active'] && $d['type'] === 'minimum_spend');
                    ?>
                    <tr>
                        <td style="color:var(--white);font-weight:500;"><?= htmlspecialchars($d['name']) ?></td>
                        <td>
                            <span class="type-badge <?= $d['type'] === 'minimum_spend' ? 'type-spend' : 'type-day' ?>">
                                <?= $d['type'] === 'minimum_spend' ? 'Min. Spend' : 'Special Day' ?>
                            </span>
                        </td>
                        <td style="color:var(--accent);font-weight:600;"><?= $d['discount_percent'] ?>%</td>
                        <td style="font-size:0.82rem;color:var(--silver);">
                            <?= $d['type'] === 'minimum_spend' ? 'Spend ≥ RM' . number_format($d['minimum_spend'], 2) : '—' ?>
                        </td>
                        <td style="font-size:0.78rem;color:var(--silver);">
                            <?php if ($d['start_date'] && $d['end_date']): ?>
                                <?= date('M j, Y', strtotime($d['start_date'])) ?><br>
                                <span style="color:var(--muted);">to <?= date('M j, Y', strtotime($d['end_date'])) ?></span>
                            <?php else: ?>
                                <span style="color:var(--muted);">Always active</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!$d['is_active']): ?>
                                <span class="active-pill pill-inactive">Inactive</span>
                            <?php elseif ($isLive): ?>
                                <span class="active-pill pill-live">● Live</span>
                            <?php else: ?>
                                <span class="active-pill pill-active">Active</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div style="display:flex;gap:0.5rem;">
                                <a href="?toggle=<?= $d['id'] ?>" class="btn btn-sm btn-dark">
                                    <?= $d['is_active'] ? 'Disable' : 'Enable' ?>
                                </a>
                                <a href="?delete=<?= $d['id'] ?>" class="btn btn-sm btn-danger"
                                   onclick="return confirm('Delete this discount?')">Delete</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </main>
</div>

<script>
function toggleTypeFields() {
    const type     = document.getElementById('typeSelect').value;
    const minField = document.getElementById('minSpendField');
    const startF   = document.getElementById('startDateField');
    const endF     = document.getElementById('endDateField');

    if (type === 'minimum_spend') {
        minField.style.display = '';
        startF.style.display   = 'none';
        endF.style.display     = 'none';
    } else {
        minField.style.display = 'none';
        startF.style.display   = '';
        endF.style.display     = '';
    }
}
</script>


