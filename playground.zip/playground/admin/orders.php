<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Manage Orders';
$db = getDB();

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $orderId   = intval($_POST['order_id']);
    $newStatus = $_POST['status'];
    $allowed   = ['pending','paid','shipped','completed','cancelled'];
    if (in_array($newStatus, $allowed)) {
        $db->prepare("UPDATE orders SET status=? WHERE id=?")->execute([$newStatus, $orderId]);
        header('Location: ' . SITE_URL . '/admin/orders.php?updated=1');
        exit;
    }
}

$filter = $_GET['status'] ?? 'all';
$sql = "SELECT o.*, u.name as customer_name, u.email as customer_email,
               COUNT(oi.id) as item_count
        FROM orders o
        JOIN users u ON u.id = o.user_id
        LEFT JOIN order_items oi ON oi.order_id = o.id
        WHERE 1=1";
$params = [];
if ($filter !== 'all') { $sql .= " AND o.status=?"; $params[] = $filter; }
$sql .= " GROUP BY o.id ORDER BY o.created_at DESC";

$orders = $db->prepare($sql);
$orders->execute($params);
$orders = $orders->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders — Admin — Playground</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<?php include __DIR__ . '/../includes/header.php'; ?>
<div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <span>Admin Panel</span>
        </div>
        <nav class="admin-nav">
            <a href="<?= SITE_URL ?>/admin/dashboard.php" class="active">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Dashboard
            </a>
            <a href="<?= SITE_URL ?>/admin/orders.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>
                Orders
            </a>
            <a href="<?= SITE_URL ?>/admin/products.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                Products
            </a>
            <a href="<?= SITE_URL ?>/admin/discounts.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
                Discounts
            </a>
            <a href="<?= SITE_URL ?>/admin/customers.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                Customers
            </a>
            <a href="<?= SITE_URL ?>/admin/reports.php">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                Reports
            </a>
            <a href="<?= SITE_URL ?>/index.php" style="margin-top:1rem;border-top:1px solid var(--border);padding-top:1rem;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                View Store
            </a>
        </nav>
    </aside>
    <main class="admin-main">
        <div class="admin-header">
            <h1>Orders</h1>
        </div>

        <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success" style="margin-bottom:1.5rem;">Order status updated successfully.</div>
        <?php endif; ?>

        <!-- Filter tabs -->
        <div style="display:flex;gap:0.5rem;margin-bottom:1.5rem;flex-wrap:wrap;">
            <?php foreach (['all','pending','paid','shipped','completed','cancelled'] as $s): ?>
            <a href="?status=<?= $s ?>" class="btn btn-sm <?= $filter===$s ? 'btn-primary' : 'btn-dark' ?>"><?= ucfirst($s) ?></a>
            <?php endforeach; ?>
        </div>

        <div class="admin-card">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Order</th><th>Customer</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($orders)): ?>
                    <tr><td colspan="7" style="text-align:center;padding:2rem;color:var(--muted);">No orders found.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td style="color:var(--white);font-weight:500;">#<?= $order['id'] ?></td>
                        <td>
                            <div style="color:var(--off-white);"><?= htmlspecialchars($order['customer_name']) ?></div>
                            <div style="font-size:0.72rem;color:var(--muted);"><?= htmlspecialchars($order['customer_email']) ?></div>
                        </td>
                        <td><?= date('M j, Y', strtotime($order['created_at'])) ?></td>
                        <td><?= $order['item_count'] ?></td>
                        <td style="color:var(--accent);font-weight:500;">$<?= number_format($order['total_amount'], 2) ?></td>
                        <td><span class="order-status status-<?= $order['status'] ?>"><?= ucfirst($order['status']) ?></span></td>
                        <td>
                            <form method="POST" style="display:flex;gap:0.5rem;align-items:center;">
                                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                <select name="status" style="background:var(--charcoal);border:1px solid var(--border);border-radius:4px;padding:0.35rem 0.6rem;color:var(--off-white);font-size:0.78rem;outline:none;">
                                    <?php foreach (['pending','paid','shipped','completed','cancelled'] as $s): ?>
                                    <option value="<?= $s ?>" <?= $order['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" name="update_status" class="btn btn-sm btn-primary">Update</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

