﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.NavigationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MainMenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateDetailsForBooksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateBorrowerDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Test1DataSet = New GroupProjectLibrary.test1DataSet()
        Me.Test1DataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LibraryCSC301DataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LibraryCSC301DataSet = New GroupProjectLibrary.LibraryCSC301DataSet()
        Me.Table1_testBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnView = New System.Windows.Forms.Button()
        Me.Table1_testTableAdapter = New GroupProjectLibrary.test1DataSetTableAdapters.Table1_testTableAdapter()
        Me.TableAdapterManager = New GroupProjectLibrary.test1DataSetTableAdapters.TableAdapterManager()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cboSearchBy = New System.Windows.Forms.ComboBox()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnResetSearch = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.dgvBooks = New System.Windows.Forms.DataGridView()
        Me.BookIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookTitleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GenreDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AuthorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AvailabilityDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.BooksBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BooksTableAdapter = New GroupProjectLibrary.LibraryCSC301DataSetTableAdapters.BooksTableAdapter()
        Me.btnTotal = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.Test1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Test1DataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LibraryCSC301DataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LibraryCSC301DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Table1_testBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvBooks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BooksBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(185, Byte), Integer), CType(CType(211, Byte), Integer))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NavigationToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(5, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1165, 26)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'NavigationToolStripMenuItem
        '
        Me.NavigationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MainMenuToolStripMenuItem, Me.UpdateDetailsForBooksToolStripMenuItem, Me.UpdateBorrowerDetailsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.NavigationToolStripMenuItem.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NavigationToolStripMenuItem.Name = "NavigationToolStripMenuItem"
        Me.NavigationToolStripMenuItem.Size = New System.Drawing.Size(89, 22)
        Me.NavigationToolStripMenuItem.Text = "Navigation"
        '
        'MainMenuToolStripMenuItem
        '
        Me.MainMenuToolStripMenuItem.Name = "MainMenuToolStripMenuItem"
        Me.MainMenuToolStripMenuItem.Size = New System.Drawing.Size(251, 26)
        Me.MainMenuToolStripMenuItem.Text = "Main Menu"
        '
        'UpdateDetailsForBooksToolStripMenuItem
        '
        Me.UpdateDetailsForBooksToolStripMenuItem.Name = "UpdateDetailsForBooksToolStripMenuItem"
        Me.UpdateDetailsForBooksToolStripMenuItem.Size = New System.Drawing.Size(251, 26)
        Me.UpdateDetailsForBooksToolStripMenuItem.Text = "Update Details for Books"
        '
        'UpdateBorrowerDetailsToolStripMenuItem
        '
        Me.UpdateBorrowerDetailsToolStripMenuItem.Name = "UpdateBorrowerDetailsToolStripMenuItem"
        Me.UpdateBorrowerDetailsToolStripMenuItem.Size = New System.Drawing.Size(251, 26)
        Me.UpdateBorrowerDetailsToolStripMenuItem.Text = "Update Borrower Details"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(251, 26)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'Test1DataSet
        '
        Me.Test1DataSet.DataSetName = "test1DataSet"
        Me.Test1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Test1DataSetBindingSource
        '
        Me.Test1DataSetBindingSource.DataSource = Me.Test1DataSet
        Me.Test1DataSetBindingSource.Position = 0
        '
        'LibraryCSC301DataSetBindingSource
        '
        Me.LibraryCSC301DataSetBindingSource.DataSource = Me.LibraryCSC301DataSet
        Me.LibraryCSC301DataSetBindingSource.Position = 0
        '
        'LibraryCSC301DataSet
        '
        Me.LibraryCSC301DataSet.DataSetName = "LibraryCSC301DataSet"
        Me.LibraryCSC301DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Table1_testBindingSource
        '
        Me.Table1_testBindingSource.DataMember = "Table1 test"
        Me.Table1_testBindingSource.DataSource = Me.Test1DataSet
        '
        'btnView
        '
        Me.btnView.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnView.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnView.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnView.ForeColor = System.Drawing.Color.White
        Me.btnView.Image = CType(resources.GetObject("btnView.Image"), System.Drawing.Image)
        Me.btnView.Location = New System.Drawing.Point(713, 400)
        Me.btnView.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnView.Name = "btnView"
        Me.btnView.Size = New System.Drawing.Size(125, 43)
        Me.btnView.TabIndex = 2
        Me.btnView.Text = "View List"
        Me.btnView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnView.UseVisualStyleBackColor = False
        '
        'Table1_testTableAdapter
        '
        Me.Table1_testTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Table1_testTableAdapter = Me.Table1_testTableAdapter
        Me.TableAdapterManager.UpdateOrder = GroupProjectLibrary.test1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(216, 117)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(153, 32)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "List of Books"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.cboSearchBy)
        Me.GroupBox1.Controls.Add(Me.txtSearch)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(222, 39)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(700, 76)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Search Box"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(384, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 21)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Search by:"
        '
        'cboSearchBy
        '
        Me.cboSearchBy.FormattingEnabled = True
        Me.cboSearchBy.Items.AddRange(New Object() {"Book_Title", "Genre", "Author"})
        Me.cboSearchBy.Location = New System.Drawing.Point(468, 32)
        Me.cboSearchBy.Margin = New System.Windows.Forms.Padding(4)
        Me.cboSearchBy.Name = "cboSearchBy"
        Me.cboSearchBy.Size = New System.Drawing.Size(160, 29)
        Me.cboSearchBy.TabIndex = 5
        '
        'txtSearch
        '
        Me.txtSearch.Location = New System.Drawing.Point(139, 32)
        Me.txtSearch.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(193, 26)
        Me.txtSearch.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(7, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(125, 21)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Enter information:"
        '
        'btnResetSearch
        '
        Me.btnResetSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnResetSearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnResetSearch.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetSearch.ForeColor = System.Drawing.Color.White
        Me.btnResetSearch.Image = CType(resources.GetObject("btnResetSearch.Image"), System.Drawing.Image)
        Me.btnResetSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnResetSearch.Location = New System.Drawing.Point(222, 400)
        Me.btnResetSearch.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnResetSearch.Name = "btnResetSearch"
        Me.btnResetSearch.Size = New System.Drawing.Size(98, 43)
        Me.btnResetSearch.TabIndex = 8
        Me.btnResetSearch.Text = "Reset"
        Me.btnResetSearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnResetSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnResetSearch.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-15, 0)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(204, 169)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'dgvBooks
        '
        Me.dgvBooks.AutoGenerateColumns = False
        Me.dgvBooks.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgvBooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvBooks.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BookIDDataGridViewTextBoxColumn, Me.BookTitleDataGridViewTextBoxColumn, Me.GenreDataGridViewTextBoxColumn, Me.AuthorDataGridViewTextBoxColumn, Me.AvailabilityDataGridViewCheckBoxColumn})
        Me.dgvBooks.DataSource = Me.BooksBindingSource
        Me.dgvBooks.Location = New System.Drawing.Point(222, 163)
        Me.dgvBooks.Name = "dgvBooks"
        Me.dgvBooks.RowHeadersWidth = 51
        Me.dgvBooks.RowTemplate.Height = 24
        Me.dgvBooks.Size = New System.Drawing.Size(678, 223)
        Me.dgvBooks.TabIndex = 10
        '
        'BookIDDataGridViewTextBoxColumn
        '
        Me.BookIDDataGridViewTextBoxColumn.DataPropertyName = "Book_ID"
        Me.BookIDDataGridViewTextBoxColumn.HeaderText = "Book_ID"
        Me.BookIDDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.BookIDDataGridViewTextBoxColumn.Name = "BookIDDataGridViewTextBoxColumn"
        Me.BookIDDataGridViewTextBoxColumn.Width = 125
        '
        'BookTitleDataGridViewTextBoxColumn
        '
        Me.BookTitleDataGridViewTextBoxColumn.DataPropertyName = "Book_Title"
        Me.BookTitleDataGridViewTextBoxColumn.HeaderText = "Book_Title"
        Me.BookTitleDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.BookTitleDataGridViewTextBoxColumn.Name = "BookTitleDataGridViewTextBoxColumn"
        Me.BookTitleDataGridViewTextBoxColumn.Width = 125
        '
        'GenreDataGridViewTextBoxColumn
        '
        Me.GenreDataGridViewTextBoxColumn.DataPropertyName = "Genre"
        Me.GenreDataGridViewTextBoxColumn.HeaderText = "Genre"
        Me.GenreDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.GenreDataGridViewTextBoxColumn.Name = "GenreDataGridViewTextBoxColumn"
        Me.GenreDataGridViewTextBoxColumn.Width = 125
        '
        'AuthorDataGridViewTextBoxColumn
        '
        Me.AuthorDataGridViewTextBoxColumn.DataPropertyName = "Author"
        Me.AuthorDataGridViewTextBoxColumn.HeaderText = "Author"
        Me.AuthorDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.AuthorDataGridViewTextBoxColumn.Name = "AuthorDataGridViewTextBoxColumn"
        Me.AuthorDataGridViewTextBoxColumn.Width = 125
        '
        'AvailabilityDataGridViewCheckBoxColumn
        '
        Me.AvailabilityDataGridViewCheckBoxColumn.DataPropertyName = "Availability"
        Me.AvailabilityDataGridViewCheckBoxColumn.HeaderText = "Availability"
        Me.AvailabilityDataGridViewCheckBoxColumn.MinimumWidth = 6
        Me.AvailabilityDataGridViewCheckBoxColumn.Name = "AvailabilityDataGridViewCheckBoxColumn"
        Me.AvailabilityDataGridViewCheckBoxColumn.Width = 125
        '
        'BooksBindingSource
        '
        Me.BooksBindingSource.DataMember = "Books"
        Me.BooksBindingSource.DataSource = Me.LibraryCSC301DataSetBindingSource
        '
        'BooksTableAdapter
        '
        Me.BooksTableAdapter.ClearBeforeFill = True
        '
        'btnTotal
        '
        Me.btnTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnTotal.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnTotal.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTotal.ForeColor = System.Drawing.Color.White
        Me.btnTotal.Image = CType(resources.GetObject("btnTotal.Image"), System.Drawing.Image)
        Me.btnTotal.Location = New System.Drawing.Point(859, 400)
        Me.btnTotal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnTotal.Name = "btnTotal"
        Me.btnTotal.Size = New System.Drawing.Size(149, 43)
        Me.btnTotal.TabIndex = 11
        Me.btnTotal.Text = "View Total Books Available"
        Me.btnTotal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnTotal.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSteelBlue
        Me.ClientSize = New System.Drawing.Size(1165, 450)
        Me.Controls.Add(Me.btnTotal)
        Me.Controls.Add(Me.dgvBooks)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnResetSearch)
        Me.Controls.Add(Me.btnView)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PictureBox1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form2"
        Me.Text = "Search for Books"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.Test1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Test1DataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LibraryCSC301DataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LibraryCSC301DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Table1_testBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvBooks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BooksBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents NavigationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MainMenuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UpdateDetailsForBooksToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Test1DataSetBindingSource As BindingSource
    Friend WithEvents Test1DataSet As test1DataSet
    Friend WithEvents btnView As Button
    Friend WithEvents Table1_testBindingSource As BindingSource
    Friend WithEvents Table1_testTableAdapter As test1DataSetTableAdapters.Table1_testTableAdapter
    Friend WithEvents TableAdapterManager As test1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnResetSearch As Button
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cboSearchBy As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents LibraryCSC301DataSetBindingSource As BindingSource
    Friend WithEvents LibraryCSC301DataSet As LibraryCSC301DataSet
    Friend WithEvents dgvBooks As DataGridView
    Friend WithEvents BooksBindingSource As BindingSource
    Friend WithEvents BooksTableAdapter As LibraryCSC301DataSetTableAdapters.BooksTableAdapter
    Friend WithEvents BookIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BookTitleDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GenreDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AuthorDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AvailabilityDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UpdateBorrowerDetailsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnTotal As Button
End Class
