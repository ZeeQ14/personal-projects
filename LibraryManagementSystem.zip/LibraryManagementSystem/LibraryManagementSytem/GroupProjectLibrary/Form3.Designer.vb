﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnLast = New System.Windows.Forms.Button()
        Me.btnFirst = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.BorrowerIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BorrowerNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhonenumDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BorrowerBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LibraryCSC301DataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LibraryCSC301DataSet = New GroupProjectLibrary.LibraryCSC301DataSet()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.txtBorrowerContact = New System.Windows.Forms.TextBox()
        Me.BorrowerBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtBorrowerName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBookID = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BorrowerTableAdapter = New GroupProjectLibrary.LibraryCSC301DataSetTableAdapters.BorrowerTableAdapter()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NavigationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MainMenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchForBooksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateBookDetailesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageRecordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BorrowerBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LibraryCSC301DataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LibraryCSC301DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BorrowerBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Sitka Display", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(213, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(224, 53)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Borrow Page"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.GroupBox1.Controls.Add(Me.btnLast)
        Me.GroupBox1.Controls.Add(Me.btnFirst)
        Me.GroupBox1.Controls.Add(Me.btnNext)
        Me.GroupBox1.Controls.Add(Me.btnPrevious)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.DataGridView1)
        Me.GroupBox1.Controls.Add(Me.btnReset)
        Me.GroupBox1.Controls.Add(Me.txtBorrowerContact)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtBorrowerName)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtBookID)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox1.Location = New System.Drawing.Point(27, 78)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(1087, 348)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Borrow Menu"
        '
        'btnLast
        '
        Me.btnLast.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnLast.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnLast.ForeColor = System.Drawing.Color.White
        Me.btnLast.Image = CType(resources.GetObject("btnLast.Image"), System.Drawing.Image)
        Me.btnLast.Location = New System.Drawing.Point(568, 256)
        Me.btnLast.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnLast.Name = "btnLast"
        Me.btnLast.Size = New System.Drawing.Size(107, 42)
        Me.btnLast.TabIndex = 15
        Me.btnLast.Text = "LAST"
        Me.btnLast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnLast.UseVisualStyleBackColor = False
        '
        'btnFirst
        '
        Me.btnFirst.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnFirst.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFirst.ForeColor = System.Drawing.Color.White
        Me.btnFirst.Image = CType(resources.GetObject("btnFirst.Image"), System.Drawing.Image)
        Me.btnFirst.Location = New System.Drawing.Point(163, 256)
        Me.btnFirst.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnFirst.Name = "btnFirst"
        Me.btnFirst.Size = New System.Drawing.Size(107, 42)
        Me.btnFirst.TabIndex = 14
        Me.btnFirst.Text = "FIRST"
        Me.btnFirst.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnFirst.UseVisualStyleBackColor = False
        '
        'btnNext
        '
        Me.btnNext.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnNext.ForeColor = System.Drawing.Color.White
        Me.btnNext.Image = CType(resources.GetObject("btnNext.Image"), System.Drawing.Image)
        Me.btnNext.Location = New System.Drawing.Point(435, 256)
        Me.btnNext.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(107, 42)
        Me.btnNext.TabIndex = 12
        Me.btnNext.Text = "NEXT"
        Me.btnNext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnNext.UseVisualStyleBackColor = False
        '
        'btnPrevious
        '
        Me.btnPrevious.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnPrevious.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPrevious.ForeColor = System.Drawing.Color.White
        Me.btnPrevious.Image = CType(resources.GetObject("btnPrevious.Image"), System.Drawing.Image)
        Me.btnPrevious.Location = New System.Drawing.Point(305, 256)
        Me.btnPrevious.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(107, 42)
        Me.btnPrevious.TabIndex = 11
        Me.btnPrevious.Text = "PREVIOUS"
        Me.btnPrevious.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnPrevious.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(541, 10)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(206, 29)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "List of current Borrower"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BorrowerIDDataGridViewTextBoxColumn, Me.BorrowerNameDataGridViewTextBoxColumn, Me.PhonenumDataGridViewTextBoxColumn, Me.BookIDDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.BorrowerBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(546, 42)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(530, 194)
        Me.DataGridView1.TabIndex = 8
        '
        'BorrowerIDDataGridViewTextBoxColumn
        '
        Me.BorrowerIDDataGridViewTextBoxColumn.DataPropertyName = "BorrowerID"
        Me.BorrowerIDDataGridViewTextBoxColumn.HeaderText = "BorrowerID"
        Me.BorrowerIDDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.BorrowerIDDataGridViewTextBoxColumn.Name = "BorrowerIDDataGridViewTextBoxColumn"
        Me.BorrowerIDDataGridViewTextBoxColumn.Width = 125
        '
        'BorrowerNameDataGridViewTextBoxColumn
        '
        Me.BorrowerNameDataGridViewTextBoxColumn.DataPropertyName = "Borrower_Name"
        Me.BorrowerNameDataGridViewTextBoxColumn.HeaderText = "Borrower_Name"
        Me.BorrowerNameDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.BorrowerNameDataGridViewTextBoxColumn.Name = "BorrowerNameDataGridViewTextBoxColumn"
        Me.BorrowerNameDataGridViewTextBoxColumn.Width = 125
        '
        'PhonenumDataGridViewTextBoxColumn
        '
        Me.PhonenumDataGridViewTextBoxColumn.DataPropertyName = "Phone_num"
        Me.PhonenumDataGridViewTextBoxColumn.HeaderText = "Phone_num"
        Me.PhonenumDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.PhonenumDataGridViewTextBoxColumn.Name = "PhonenumDataGridViewTextBoxColumn"
        Me.PhonenumDataGridViewTextBoxColumn.Width = 125
        '
        'BookIDDataGridViewTextBoxColumn
        '
        Me.BookIDDataGridViewTextBoxColumn.DataPropertyName = "Book_ID"
        Me.BookIDDataGridViewTextBoxColumn.HeaderText = "Book_ID"
        Me.BookIDDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.BookIDDataGridViewTextBoxColumn.Name = "BookIDDataGridViewTextBoxColumn"
        Me.BookIDDataGridViewTextBoxColumn.Width = 125
        '
        'BorrowerBindingSource
        '
        Me.BorrowerBindingSource.DataMember = "Borrower"
        Me.BorrowerBindingSource.DataSource = Me.LibraryCSC301DataSetBindingSource
        '
        'LibraryCSC301DataSetBindingSource
        '
        Me.LibraryCSC301DataSetBindingSource.DataSource = Me.LibraryCSC301DataSet
        Me.LibraryCSC301DataSetBindingSource.Position = 0
        '
        'LibraryCSC301DataSet
        '
        Me.LibraryCSC301DataSet.DataSetName = "LibraryCSC301DataSet"
        Me.LibraryCSC301DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnReset
        '
        Me.btnReset.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReset.ForeColor = System.Drawing.Color.White
        Me.btnReset.Image = CType(resources.GetObject("btnReset.Image"), System.Drawing.Image)
        Me.btnReset.Location = New System.Drawing.Point(29, 256)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(107, 42)
        Me.btnReset.TabIndex = 7
        Me.btnReset.Text = "Reset"
        Me.btnReset.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnReset.UseVisualStyleBackColor = False
        '
        'txtBorrowerContact
        '
        Me.txtBorrowerContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBorrowerContact.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BorrowerBindingSource1, "Phone_num", True))
        Me.txtBorrowerContact.Location = New System.Drawing.Point(249, 174)
        Me.txtBorrowerContact.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBorrowerContact.Name = "txtBorrowerContact"
        Me.txtBorrowerContact.Size = New System.Drawing.Size(241, 26)
        Me.txtBorrowerContact.TabIndex = 5
        '
        'BorrowerBindingSource1
        '
        Me.BorrowerBindingSource1.DataMember = "Borrower"
        Me.BorrowerBindingSource1.DataSource = Me.LibraryCSC301DataSet
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 177)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(219, 21)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Enter Borrower's Phone Number:"
        '
        'txtBorrowerName
        '
        Me.txtBorrowerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBorrowerName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BorrowerBindingSource1, "Borrower_Name", True))
        Me.txtBorrowerName.Location = New System.Drawing.Point(249, 113)
        Me.txtBorrowerName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBorrowerName.Name = "txtBorrowerName"
        Me.txtBorrowerName.Size = New System.Drawing.Size(241, 26)
        Me.txtBorrowerName.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(25, 115)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(163, 21)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Enter Borrower's Name:"
        '
        'txtBookID
        '
        Me.txtBookID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBookID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BorrowerBindingSource1, "Book_ID", True))
        Me.txtBookID.Location = New System.Drawing.Point(249, 51)
        Me.txtBookID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtBookID.Name = "txtBookID"
        Me.txtBookID.Size = New System.Drawing.Size(241, 26)
        Me.txtBookID.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 21)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Enter Book ID:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-16, 0)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(154, 97)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'BorrowerTableAdapter
        '
        Me.BorrowerTableAdapter.ClearBeforeFill = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.NavigationToolStripMenuItem, Me.ManageRecordsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1143, 28)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(46, 24)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(116, 26)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'NavigationToolStripMenuItem
        '
        Me.NavigationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MainMenuToolStripMenuItem, Me.SearchForBooksToolStripMenuItem, Me.UpdateBookDetailesToolStripMenuItem})
        Me.NavigationToolStripMenuItem.Name = "NavigationToolStripMenuItem"
        Me.NavigationToolStripMenuItem.Size = New System.Drawing.Size(96, 24)
        Me.NavigationToolStripMenuItem.Text = "Navigation"
        '
        'MainMenuToolStripMenuItem
        '
        Me.MainMenuToolStripMenuItem.Name = "MainMenuToolStripMenuItem"
        Me.MainMenuToolStripMenuItem.Size = New System.Drawing.Size(237, 26)
        Me.MainMenuToolStripMenuItem.Text = "Main Menu"
        '
        'SearchForBooksToolStripMenuItem
        '
        Me.SearchForBooksToolStripMenuItem.Name = "SearchForBooksToolStripMenuItem"
        Me.SearchForBooksToolStripMenuItem.Size = New System.Drawing.Size(237, 26)
        Me.SearchForBooksToolStripMenuItem.Text = "Search for Books"
        '
        'UpdateBookDetailesToolStripMenuItem
        '
        Me.UpdateBookDetailesToolStripMenuItem.Name = "UpdateBookDetailesToolStripMenuItem"
        Me.UpdateBookDetailesToolStripMenuItem.Size = New System.Drawing.Size(237, 26)
        Me.UpdateBookDetailesToolStripMenuItem.Text = "Update Book Detailes"
        '
        'ManageRecordsToolStripMenuItem
        '
        Me.ManageRecordsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToolStripMenuItem, Me.RemoveToolStripMenuItem, Me.SaveToolStripMenuItem})
        Me.ManageRecordsToolStripMenuItem.Name = "ManageRecordsToolStripMenuItem"
        Me.ManageRecordsToolStripMenuItem.Size = New System.Drawing.Size(134, 24)
        Me.ManageRecordsToolStripMenuItem.Text = "Manage Records"
        '
        'AddToolStripMenuItem
        '
        Me.AddToolStripMenuItem.Name = "AddToolStripMenuItem"
        Me.AddToolStripMenuItem.Size = New System.Drawing.Size(146, 26)
        Me.AddToolStripMenuItem.Text = "Add"
        '
        'RemoveToolStripMenuItem
        '
        Me.RemoveToolStripMenuItem.Name = "RemoveToolStripMenuItem"
        Me.RemoveToolStripMenuItem.Size = New System.Drawing.Size(146, 26)
        Me.RemoveToolStripMenuItem.Text = "Remove"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(146, 26)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSteelBlue
        Me.ClientSize = New System.Drawing.Size(1143, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PictureBox1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form3"
        Me.Text = "Borrow Page"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BorrowerBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LibraryCSC301DataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LibraryCSC301DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BorrowerBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtBookID As TextBox
    Friend WithEvents txtBorrowerName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnReset As Button
    Friend WithEvents txtBorrowerContact As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents LibraryCSC301DataSetBindingSource As BindingSource
    Friend WithEvents LibraryCSC301DataSet As LibraryCSC301DataSet
    Friend WithEvents BorrowerBindingSource As BindingSource
    Friend WithEvents BorrowerTableAdapter As LibraryCSC301DataSetTableAdapters.BorrowerTableAdapter
    Friend WithEvents BorrowerIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BorrowerNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PhonenumDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BookIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Label5 As Label
    Friend WithEvents btnNext As Button
    Friend WithEvents btnPrevious As Button
    Friend WithEvents btnLast As Button
    Friend WithEvents btnFirst As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NavigationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MainMenuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchForBooksToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UpdateBookDetailesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManageRecordsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BorrowerBindingSource1 As BindingSource
End Class
