﻿Imports System.Data.OleDb
Public Class FormLogin

    Private connStr As String =
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\User\OneDrive\Desktop\CSC301 lab\GroupProjectLibrary ver5\GroupProjectLibrary ver4\GroupProjectLibrary\LibraryCSC301.accdb;"
    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim sql As String =
        "SELECT COUNT(*) FROM Librarian_ID WHERE Username = ? AND [Password] = ?"


        Using conn As New OleDbConnection(connStr)
            Using cmd As New OleDbCommand(sql, conn)


                cmd.Parameters.AddWithValue("?", txtLoginUsername.Text)
                cmd.Parameters.AddWithValue("?", txtLoginPassword.Text)


                conn.Open()
                Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())


                If count = 1 Then
                    MessageBox.Show("Login Successful!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information)


                    ' Example: open main menu
                    Form1.Show()
                    Me.Hide()


                Else
                    MessageBox.Show("Invalid Username or Password", "Login Failed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If


            End Using
        End Using
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtLoginPassword.Clear()
        txtLoginUsername.Clear()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class