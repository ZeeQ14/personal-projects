﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Public Class FormUpdate
    Private Sub FormUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LibraryCSC301DataSet.Books' table. You can move, or remove it, as needed.
        'Me.BooksTableAdapter.Fill(Me.LibraryCSC301DataSet.Books)'
        'TODO: This line of code loads data into the 'Test1DataSet.Table1_test' table. You can move, or remove it, as needed.
        'Me.Table1_testTableAdapter.Fill(Me.Test1DataSet.Table1_test)
        txtID.DataBindings.Clear()
        txtTitle.DataBindings.Clear()
        txtGenre.DataBindings.Clear()
        txtAuthor.DataBindings.Clear()
        chkAvailability.DataBindings.Clear()

        txtID.DataBindings.Add("Text", BooksBindingSource, "Book_ID")
        txtTitle.DataBindings.Add("Text", BooksBindingSource, "Book_Title")
        txtGenre.DataBindings.Add("Text", BooksBindingSource, "Genre")
        txtAuthor.DataBindings.Add("Text", BooksBindingSource, "Author")
        chkAvailability.DataBindings.Add("Checked", BooksBindingSource, "Availability")

    End Sub

    Private Sub MainMenuToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MainMenuToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub SearchForBooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchForBooksToolStripMenuItem.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub UpdateBorrowerDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateBorrowerDetailsToolStripMenuItem.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub AddToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddToolStripMenuItem.Click
        Me.BooksBindingSource.AddNew()
    End Sub
    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        Try
            Me.Validate()
            Me.BooksBindingSource.EndEdit()
            ' If using TableAdapterManager
            Me.BooksTableAdapter.Update(Me.LibraryCSC301DataSet)
            ' Or if not using TableAdapterManager
            ' Me.BooksTableAdapter.Update(Me.LibraryCSC301DataSet.Books)
            MessageBox.Show("Record Saved Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error saving record: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub RemoveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveToolStripMenuItem.Click
        Me.BooksBindingSource.RemoveCurrent()
    End Sub
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub btnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        Me.BooksBindingSource.MoveFirst()
    End Sub
    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        Me.BooksBindingSource.MovePrevious()
    End Sub
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        Me.BooksBindingSource.MoveNext()
    End Sub
    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        Me.BooksBindingSource.MoveLast()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        BooksBindingSource.CancelEdit()
    End Sub

    Private Sub ViewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewToolStripMenuItem.Click
        Me.BooksTableAdapter.Fill(Me.LibraryCSC301DataSet.Books)
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class