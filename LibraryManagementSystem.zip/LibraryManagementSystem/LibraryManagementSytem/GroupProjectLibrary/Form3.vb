﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO
Public Class Form3
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LibraryCSC301DataSet.Borrower' table. You can move, or remove it, as needed.
        Me.BorrowerTableAdapter.Fill(Me.LibraryCSC301DataSet.Borrower)
        txtBookID.DataBindings.Clear()
        txtBorrowerName.DataBindings.Clear()
        txtBorrowerContact.DataBindings.Clear()

        txtBookID.DataBindings.Add("Text", BorrowerBindingSource, "Book_ID")
        txtBorrowerName.DataBindings.Add("Text", BorrowerBindingSource, "Borrower_Name")
        txtBorrowerContact.DataBindings.Add("Text", BorrowerBindingSource, "Phone_num")
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        BorrowerBindingSource.CancelEdit()
    End Sub

    Private Sub btnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        Me.BorrowerBindingSource.MoveFirst()
    End Sub
    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        Me.BorrowerBindingSource.MovePrevious()
    End Sub
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        Me.BorrowerBindingSource.MoveNext()
    End Sub
    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        Me.BorrowerBindingSource.MoveLast()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub MainMenuToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MainMenuToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub UpdateBookDetailesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateBookDetailesToolStripMenuItem.Click
        FormUpdate.Show()
        Me.Hide()
    End Sub

    Private Sub SearchForBooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchForBooksToolStripMenuItem.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub AddToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddToolStripMenuItem.Click
        Me.BorrowerBindingSource.AddNew()
    End Sub

    Private Sub RemoveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveToolStripMenuItem.Click
        Me.BorrowerBindingSource.RemoveCurrent()
    End Sub

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        Try
            Me.Validate()
            Me.BorrowerBindingSource.EndEdit()
            ' If using TableAdapterManager
            Me.BorrowerTableAdapter.Update(Me.LibraryCSC301DataSet)
            ' Or if not using TableAdapterManager
            ' Me.BorrowerTableAdapter.Update(Me.LibraryCSC301DataSet.Borrower)
            MessageBox.Show("Record Saved Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error saving record: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class