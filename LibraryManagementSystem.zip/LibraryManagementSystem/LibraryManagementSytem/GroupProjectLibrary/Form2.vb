﻿Imports System.Data
Imports System.Data.OleDb
Imports System.IO

Public Class Form2
    Private Sub MainMenuToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MainMenuToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()
    End Sub
    Private Sub UpdateBorrowerDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateBorrowerDetailsToolStripMenuItem.Click
        Form3.Show()
        Me.Hide()
    End Sub
    Private Sub UpdateDetailsForBooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateDetailsForBooksToolStripMenuItem.Click
        FormUpdate.Show()
        Me.Hide()
    End Sub


    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        LoadBooks()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LibraryCSC301DataSet.Books' table. You can move, or remove it, as needed.
        'LoadBooks()'
        ' Load data safely on form load
        ' create source once (e.g., Form_Load)
        Dim items = New List(Of KeyValuePair(Of String, String)) From {
            New KeyValuePair(Of String, String)("Book_Title", "Book_Title"),
            New KeyValuePair(Of String, String)("Genre", "Genre"),
            New KeyValuePair(Of String, String)("Author", "Author")
        }
        cboSearchBy.DataSource = items
        cboSearchBy.DisplayMember = "Key"
        cboSearchBy.ValueMember = "Value"

    End Sub

    Private Sub btnResetSearch_Click(sender As Object, e As EventArgs) Handles btnResetSearch.Click
        txtSearch.Clear()

    End Sub
    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        If txtSearch.Text <> "" And cboSearchBy.SelectedIndex <> -1 Then
            SearchBooks()
        End If
    End Sub

    Private Sub LoadBooks()
        Me.BooksTableAdapter.Fill(Me.LibraryCSC301DataSet.Books)
    End Sub

    Private Sub SearchBooks()
        If cboSearchBy.SelectedIndex = -1 Or txtSearch.Text = "" Then
            MessageBox.Show("Please select a search type and enter text.")
            Exit Sub
        End If

        Dim filterColumn As String = cboSearchBy.SelectedValue.ToString()

        ' DataView filter
        Dim dv As New DataView(LibraryCSC301DataSet.Books)

        dv.RowFilter = String.Format(
            "[{0}] LIKE '%{1}%'",
            filterColumn.Replace("'", "''"),
            txtSearch.Text.Replace("'", "''")
        )

        dgvBooks.DataSource = dv
    End Sub



    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub btnTotal_Click(sender As Object, e As EventArgs) Handles btnTotal.Click
        Dim total As Integer = CountAvailableBooks()

        MessageBox.Show(
        "Total books available: " & total.ToString(),
        "Inventory",
        MessageBoxButtons.OK,
        MessageBoxIcon.Information
    )
    End Sub

    Private Function CountAvailableBooks() As Integer
        Dim total As Integer = 0

        For Each row As LibraryCSC301DataSet.BooksRow In LibraryCSC301DataSet.Books
            If row.Availability = True Then
                total += 1
            End If
        Next

        Return total
    End Function
End Class