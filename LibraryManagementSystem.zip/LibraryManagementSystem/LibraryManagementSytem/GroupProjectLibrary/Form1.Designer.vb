﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnMenuSearchBooks = New System.Windows.Forms.Button()
        Me.btnMenuUpdDetails = New System.Windows.Forms.Button()
        Me.btnMenuBorrow = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Test1DataSet1 = New GroupProjectLibrary.test1DataSet()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Test1DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnExit.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(1001, 384)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(99, 54)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(204, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(650, 41)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Welcome to the Library Management System"
        '
        'btnMenuSearchBooks
        '
        Me.btnMenuSearchBooks.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnMenuSearchBooks.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMenuSearchBooks.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuSearchBooks.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnMenuSearchBooks.Image = CType(resources.GetObject("btnMenuSearchBooks.Image"), System.Drawing.Image)
        Me.btnMenuSearchBooks.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuSearchBooks.Location = New System.Drawing.Point(440, 263)
        Me.btnMenuSearchBooks.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnMenuSearchBooks.Name = "btnMenuSearchBooks"
        Me.btnMenuSearchBooks.Size = New System.Drawing.Size(229, 52)
        Me.btnMenuSearchBooks.TabIndex = 5
        Me.btnMenuSearchBooks.Text = "Search for Books"
        Me.btnMenuSearchBooks.UseVisualStyleBackColor = False
        '
        'btnMenuUpdDetails
        '
        Me.btnMenuUpdDetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnMenuUpdDetails.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMenuUpdDetails.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuUpdDetails.ForeColor = System.Drawing.Color.White
        Me.btnMenuUpdDetails.Image = CType(resources.GetObject("btnMenuUpdDetails.Image"), System.Drawing.Image)
        Me.btnMenuUpdDetails.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuUpdDetails.Location = New System.Drawing.Point(440, 325)
        Me.btnMenuUpdDetails.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnMenuUpdDetails.Name = "btnMenuUpdDetails"
        Me.btnMenuUpdDetails.Size = New System.Drawing.Size(229, 52)
        Me.btnMenuUpdDetails.TabIndex = 6
        Me.btnMenuUpdDetails.Text = "Update Detais on Books"
        Me.btnMenuUpdDetails.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnMenuUpdDetails.UseVisualStyleBackColor = False
        '
        'btnMenuBorrow
        '
        Me.btnMenuBorrow.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(95, Byte), Integer))
        Me.btnMenuBorrow.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMenuBorrow.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuBorrow.ForeColor = System.Drawing.Color.White
        Me.btnMenuBorrow.Image = CType(resources.GetObject("btnMenuBorrow.Image"), System.Drawing.Image)
        Me.btnMenuBorrow.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMenuBorrow.Location = New System.Drawing.Point(440, 386)
        Me.btnMenuBorrow.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnMenuBorrow.Name = "btnMenuBorrow"
        Me.btnMenuBorrow.Size = New System.Drawing.Size(229, 52)
        Me.btnMenuBorrow.TabIndex = 8
        Me.btnMenuBorrow.Text = "Borrow Books"
        Me.btnMenuBorrow.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(455, 73)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(200, 185)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'Test1DataSet1
        '
        Me.Test1DataSet1.DataSetName = "test1DataSet"
        Me.Test1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1111, 450)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnMenuBorrow)
        Me.Controls.Add(Me.btnMenuUpdDetails)
        Me.Controls.Add(Me.btnMenuSearchBooks)
        Me.Controls.Add(Me.btnExit)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form1"
        Me.Text = "Main Menu"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Test1DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnMenuSearchBooks As Button
    Friend WithEvents btnMenuUpdDetails As Button
    Friend WithEvents btnMenuBorrow As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Test1DataSet1 As test1DataSet
End Class
