﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub btnSearchBooks_Click(sender As Object, e As EventArgs) Handles btnMenuSearchBooks.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnMenuUpdDetails_Click(sender As Object, e As EventArgs) Handles btnMenuUpdDetails.Click
        FormUpdate.Show()
        Me.Hide()
    End Sub

    Private Sub btnMenuBorrow_Click(sender As Object, e As EventArgs) Handles btnMenuBorrow.Click
        Form3.Show()
        Me.Hide()
    End Sub
End Class
